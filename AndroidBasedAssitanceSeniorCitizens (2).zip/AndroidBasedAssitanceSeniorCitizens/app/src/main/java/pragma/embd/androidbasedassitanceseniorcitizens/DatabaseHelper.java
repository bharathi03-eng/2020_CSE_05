package pragma.embd.androidbasedassitanceseniorcitizens;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;


public class DatabaseHelper extends SQLiteOpenHelper {

	
	 public static final String DataDetails_info_TABLE_NAME = "datadetails_info";
	
	 
	public DatabaseHelper(Context context) {
		
		
		super(context, "assistseniorcitizens.db", null, 1);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		
		db.execSQL("CREATE TABLE " + DataDetails_info_TABLE_NAME + "("
				+ BaseColumns._ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT, datetime VARCHAR, temperature VARCHAR, smoke VARCHAR, obstacles VARCHAR, torch VARCHAR)");
	}


	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// Steps to upgrade the database for the new version ...
	}
}

