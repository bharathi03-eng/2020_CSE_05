package pragma.embd.androidbasedassitanceseniorcitizens;

public class Constants {

    public static String str_phoneno = "";

    public static final String FIRST_COLUMN = "first";
    public static final String SECOND_COLUMN = "second";
    public static final String THIRD_COLUMN = "third";
    public static final String FOURTH_COLUMN = "fourth";
    public static final String FIFTH_COLUMN = "fifth";
    public static final String SIXTH_COLUMN = "sixth";

}
