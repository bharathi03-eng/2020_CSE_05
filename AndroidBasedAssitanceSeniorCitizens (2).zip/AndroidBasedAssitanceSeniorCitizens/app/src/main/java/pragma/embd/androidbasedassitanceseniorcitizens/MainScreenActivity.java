package pragma.embd.androidbasedassitanceseniorcitizens;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothDevice;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class MainScreenActivity extends Activity {

    Button btn_register_number, btn_voice_input, btn_connect_bluetooth, btn_view_data;
    TextView tv_voice_input;

    protected static final int RESULT_SPEECH = 11;

    LocationManager mlocManager;
    LocationListener mlocListener;
    Context ctx;
    private static final int MY_PERMISSIONS_REQUEST_NETWORK_PROVIDER =1;
    double c_lat;
    double c_long;

    String str_c_lat;
    String str_c_long;




    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainscreen);

        btn_register_number = (Button)findViewById(R.id.btn_register_number);
        btn_voice_input = (Button)findViewById(R.id.btn_voice_input);
        btn_connect_bluetooth = (Button)findViewById(R.id.btn_connect_bluetooth);
        btn_view_data = (Button)findViewById(R.id.btn_view_data);

        tv_voice_input = (TextView)findViewById(R.id.tv_voice_input);

        ctx = this;



        btn_register_number.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent registerNumberScreen = new Intent(getApplicationContext(), RegisterNumberScreenActivity.class);
                startActivity(registerNumberScreen);
            }
        });

        btn_voice_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
                try {
                    startActivityForResult(intent, RESULT_SPEECH);
                    tv_voice_input.setText("");
                } catch (ActivityNotFoundException a) {
                    Toast t = Toast . makeText (getApplicationContext(),
                            "Oops! Your device doesn't support Speech to Text",
                            Toast.LENGTH_SHORT);
                    t.show();
                }
            }
        });

        btn_connect_bluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent connectBluetoothScreen = new Intent(getApplicationContext(), ConnectBluetoothScreenActivity.class);
                startActivity(connectBluetoothScreen);
            }
        });

        btn_view_data.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                finish();
                Intent i = new Intent(view.getContext(), ViewDataScreenActivity.class);
                startActivity(i);
            }
        });

    }



    @RequiresApi(api = Build.VERSION_CODES.M)
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        //	Toast.makeText(getApplicationContext(),"requestCode" + RESULT_SPEECH, Toast.LENGTH_LONG).show();
        switch (requestCode)
        {
            case RESULT_SPEECH:
                //Toast.makeText(getApplicationContext(), "IntoSpeach Result", Toast.LENGTH_LONG).show();
                if (resultCode == RESULT_OK && null != data) {
                    try {
                        ArrayList text = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                        String usercommand = text.get(0).toString();
                        tv_voice_input.setText(usercommand);

                        if (usercommand.equalsIgnoreCase("HELP")) {
                            get_lat_long_details();
                        } else {

                            }

                    }
                    catch(Exception ex)
                    {
                        Toast.makeText(getApplicationContext(), ex.getMessage(), Toast.LENGTH_LONG).show();
                    }


                }
                break;
        }
    }

    private void get_lat_long_details() {

        try {

            mlocManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

            mlocListener = new MainScreenActivity.MyLocationListener();
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(getApplicationContext(), "in first if",
                        Toast.LENGTH_LONG).show();
                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION)) {

                    Toast.makeText(getApplicationContext(), "in second if",
                            Toast.LENGTH_LONG).show();
                } else {

                    // permission is already granted
                    Toast.makeText(getApplicationContext(), "in else",
                            Toast.LENGTH_LONG).show();
                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                            MY_PERMISSIONS_REQUEST_NETWORK_PROVIDER);
                }


            } else {

               /* Toast.makeText(getApplicationContext(), "in secondelse",
                        Toast.LENGTH_LONG).show();*/
                mlocManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0,
                        0, mlocListener);

            }
        } catch (Exception e) {

            Toast.makeText(getApplicationContext(),

                    "error is: " + e.getMessage(),

                    Toast.LENGTH_LONG).show();
        }
    }

    /* Class My Location Listener */

    public class MyLocationListener implements LocationListener

    {
        public void onLocationChanged(Location loc)
        {
            c_lat = loc.getLatitude();
            c_long = loc.getLongitude();

            str_c_lat = Double.toString(c_lat);
            str_c_long = Double.toString(c_long);

            Toast.makeText(getApplicationContext(),
                    "latitude->" + c_lat + "\n" + "longitude->" + c_long + "\n",
                    Toast.LENGTH_LONG).show();

            mlocManager.removeUpdates(mlocListener);

            String address = getAddress(getApplicationContext(), c_lat, c_long);
            Toast.makeText(getApplicationContext(), "Address is: " + address, Toast.LENGTH_LONG).show();

            sendSMS("My current Location: " + address, Constants.str_phoneno);
        }

        public void onProviderDisabled(String provider)

        {
            Toast.makeText(getApplicationContext(),
                    "Gps Disabled",
                    Toast.LENGTH_SHORT).show();

        }

        public void onProviderEnabled(String provider)

        {
            Toast.makeText(getApplicationContext(),
                    "Gps Enabled",
                    Toast.LENGTH_SHORT).show();

        }

        public void onStatusChanged(String provider, int status, Bundle extras)

        {

        }

    }/* End of Class MyLocationListener */


    public static String getAddress(Context context, double LATITUDE, double LONGITUDE){
        //Set Address
        try {

            String TAG = "Log";
            Geocoder geocoder = new Geocoder(context, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1);

            if (addresses != null && addresses.size() > 0) {
                String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                String city = addresses.get(0).getLocality();
                String state = addresses.get(0).getAdminArea();
                String country = addresses.get(0).getCountryName();
                String postalCode = addresses.get(0).getPostalCode();
                String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL
                Log.d(TAG, "getAddress:  address" + address);
                Log.d(TAG, "getAddress:  city" + city);
                Log.d(TAG, "getAddress:  state" + state);
                Log.d(TAG, "getAddress:  postalCode" + postalCode);
                Log.d(TAG, "getAddress:  knownName" + knownName);

                return address;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    void  sendSMS(String msg, String number){
        try {

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("+91" + number, null, msg, null, null);
            //smsManager.sendTextMessage("+91" + et_mobile_no_2.getText().toString().trim(), null, msg, null, null);

            Toast.makeText(getApplicationContext(),
                    "SMS Sent Successfully",
                    Toast.LENGTH_SHORT).show();


        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),
                    "SMS faild, please try again later!" + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            //	e.printStackTrace();
        }

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}