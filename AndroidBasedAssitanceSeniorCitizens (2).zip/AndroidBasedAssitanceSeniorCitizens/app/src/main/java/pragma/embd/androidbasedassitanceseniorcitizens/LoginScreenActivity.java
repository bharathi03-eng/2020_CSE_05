package pragma.embd.androidbasedassitanceseniorcitizens;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.Locale;


public class LoginScreenActivity extends Activity {

    EditText et_username, et_pwd;
    Button btn_login;

    private static final int MY_PERMISSIONS_REQUEST_BLUETOOTH =1 ;
    TextToSpeech speak;/**/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginscreen);

        et_username = (EditText) findViewById(R.id.et_username);
        et_pwd = (EditText) findViewById(R.id.et_pwd);
        btn_login = (Button)findViewById(R.id.btn_login);


        requestForPermissions();




        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (et_username.getText().toString().trim().equals("") ||
                        et_username.getText().toString().trim().length() == 0) {
                    et_username.setError("Enter Username");
                }
                else if (et_pwd.getText().toString().trim().equals("") ||
                        et_pwd.getText().toString().trim().length() == 0) {
                    et_pwd.setError("Enter password");
                }
                else if (et_username.getText().toString().trim().equals("bpsv") ||
                        et_pwd.getText().toString().trim().equals("bpsv")) {
                    finish();
                    Intent mainScreen = new Intent(getApplicationContext(),MainScreenActivity.class);
                    startActivity(mainScreen);
                }
                else{
                        Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }

            }
        });
    }


    void requestForPermissions(){

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.BLUETOOTH)
                != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(getApplicationContext(), "in first if",
                    Toast.LENGTH_LONG).show();
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.BLUETOOTH)) {

                Toast.makeText(getApplicationContext(), "in second if",
                        Toast.LENGTH_LONG).show();
            } else {

                // permission is already granted
               /* Toast.makeText(getApplicationContext(), "in else",
                        Toast.LENGTH_LONG).show();*/
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH},
                        MY_PERMISSIONS_REQUEST_BLUETOOTH);
            }


        } else {
           /* mlocManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0,
                    0, mlocListener);*/

        }

    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}

