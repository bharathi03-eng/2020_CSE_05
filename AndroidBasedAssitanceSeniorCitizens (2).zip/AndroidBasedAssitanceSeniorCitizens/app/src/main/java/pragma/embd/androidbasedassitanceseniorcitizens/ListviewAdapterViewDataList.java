package pragma.embd.androidbasedassitanceseniorcitizens;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

import static pragma.embd.androidbasedassitanceseniorcitizens.Constants.FIRST_COLUMN;
import static pragma.embd.androidbasedassitanceseniorcitizens.Constants.SECOND_COLUMN;
import static pragma.embd.androidbasedassitanceseniorcitizens.Constants.THIRD_COLUMN;
import static pragma.embd.androidbasedassitanceseniorcitizens.Constants.FOURTH_COLUMN;
import static pragma.embd.androidbasedassitanceseniorcitizens.Constants.FIFTH_COLUMN;

public class ListviewAdapterViewDataList extends BaseAdapter
{
    public ArrayList<HashMap> list;
    Activity activity;

    DatabaseHelper helper;
    private SQLiteDatabase database;



    public ListviewAdapterViewDataList(Activity activity, ArrayList<HashMap> list) {

        super();
        this.activity = activity;
        this.list = list;

    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }
    public void toggleItem(int position) {
        HashMap map = list.get(position);

        this.notifyDataSetChanged();
    }
    private class ViewHolder {

        TextView tv_datetime;
        TextView tv_temp;
        TextView tv_smoke;
        TextView tv_obstacles;
        TextView tv_torch;
        Button btn_action;

    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        try{

            // TODO Auto-generated method stub
            View row = convertView;
            LinearLayout listLayout = new LinearLayout(activity);
            LayoutParams lpView = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            listLayout.setOrientation(LinearLayout.HORIZONTAL);
            listLayout.setId(5000);
            final ViewHolder holder;
            LayoutInflater inflater =  activity.getLayoutInflater();

            if (convertView == null)
            {
                convertView = inflater.inflate(R.layout.listviewdatalist,parent,false);
                holder = new ViewHolder();
                holder.tv_datetime = (TextView) convertView.findViewById(R.id.tv_datetime);
                holder.tv_temp = (TextView) convertView.findViewById(R.id.tv_temp);
                holder.tv_smoke = (TextView) convertView.findViewById(R.id.tv_smoke);
                holder.tv_obstacles = (TextView) convertView.findViewById(R.id.tv_obstacles);
                holder.tv_torch = (TextView) convertView.findViewById(R.id.tv_torch);
                holder.btn_action = (Button) convertView.findViewById(R.id.btn_action);


                convertView.setTag(holder);
            }
            else
            {
                holder = (ViewHolder) convertView.getTag();
            }

            HashMap map = list.get(position);
            holder.tv_datetime.setText((String)map.get(FIRST_COLUMN));
            holder.tv_temp.setText((String)map.get(SECOND_COLUMN));
            holder.tv_smoke.setText((String)map.get(THIRD_COLUMN));
            holder.tv_obstacles.setText((String)map.get(FOURTH_COLUMN));
            holder.tv_torch.setText((String)map.get(FIFTH_COLUMN));


            holder.btn_action.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub

                    helper = new DatabaseHelper(activity);
                    database = helper.getWritableDatabase();

                    //String selection = "dates=? AND times=?";
                    String selection = "dates=?";
                    /*String[] selectionArgs = {holder.tv_dates.getText().toString().trim(),
                            holder.tv_times.getText().toString().trim()};*/

                    String[] selectionArgs = {holder.tv_datetime.getText().toString().trim()};

                    database.delete(DatabaseHelper.DataDetails_info_TABLE_NAME, selection, selectionArgs);
                    Toast.makeText(activity.getApplicationContext(), "Data Deleted Successfully", Toast.LENGTH_SHORT).show();

                    activity.finish();
                    Intent mainscreen = new Intent(activity.getApplicationContext(), MainScreenActivity.class);
                    activity.startActivity(mainscreen);
                }
            });

        }
        catch(Exception e){
            Toast.makeText(activity.getApplicationContext(), "Sorry No Data Exists",  Toast.LENGTH_SHORT).show();
        }

        return convertView;
    }



    protected Context getApplicationContext() {
        // TODO Auto-generated method stub
        return null;
    }

}
