package pragma.embd.androidbasedassitanceseniorcitizens;

public class BeanDetails {
	
	public String Value1, Value2, Value3,Value4,Value5,Value6;
	
	public BeanDetails(){
		
	}

	public BeanDetails(String value1, String value2, String value3){

		Value1 = value1;
		Value2 = value2;
		Value3 = value3;

	}
	
public BeanDetails(String value1, String value2, String value3, String value4){
		
		Value1 = value1;
		Value2 = value2;
		Value3 = value3;
		Value4 = value4;
		
	}

	public BeanDetails(String value1, String value2, String value3, String value4, String value5){

		Value1 = value1;
		Value2 = value2;
		Value3 = value3;
		Value4 = value4;
		Value5 = value5;

	}


	public BeanDetails(String value1, String value2, String value3, String value4, String value5, String value6){
		
		Value1 = value1;
		Value2 = value2;
		Value3 = value3;
		Value4 = value4;
		Value5 = value5;
		Value6 = value6;
		
	}
	
	
	

}
