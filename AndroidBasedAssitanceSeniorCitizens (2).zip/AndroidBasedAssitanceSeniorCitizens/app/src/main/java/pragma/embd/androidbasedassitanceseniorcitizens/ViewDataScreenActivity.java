package pragma.embd.androidbasedassitanceseniorcitizens;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

import static pragma.embd.androidbasedassitanceseniorcitizens.Constants.FIRST_COLUMN;
import static pragma.embd.androidbasedassitanceseniorcitizens.Constants.SECOND_COLUMN;
import static pragma.embd.androidbasedassitanceseniorcitizens.Constants.THIRD_COLUMN;
import static pragma.embd.androidbasedassitanceseniorcitizens.Constants.FOURTH_COLUMN;
import static pragma.embd.androidbasedassitanceseniorcitizens.Constants.FIFTH_COLUMN;

public class ViewDataScreenActivity extends Activity {
    ListView listView1;

    ArrayList<BeanDetails> ar_bean;
    private ArrayList<HashMap> list;
    BeanDetails bean = new BeanDetails();

    DatabaseHelper helper;
    SQLiteDatabase database;
    Cursor cursor;

    Activity act;
    private static final String fields[] = {"datetime", "temperature", "smoke", "obstacles", "torch"};
    ListAdapter adapter;

	@SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewdatascreen);

        try{
            listView1 = (ListView) findViewById(R.id.listView1);
            act = this;
            helper = new DatabaseHelper(this);
            ar_bean = new ArrayList<BeanDetails>();
            list = new ArrayList<HashMap>();

            database = helper.getReadableDatabase();
            ar_bean = getData();

            if(ar_bean.size()>0){
                for(int i=0 ; i<ar_bean.size();i++)
                {
                    BeanDetails data = ar_bean.get(i);
                    HashMap temp = new HashMap();
                    temp.put(FIRST_COLUMN, data.Value1);
                    temp.put(SECOND_COLUMN, data.Value2);
                    temp.put(THIRD_COLUMN, data.Value3);
                    temp.put(FOURTH_COLUMN, data.Value4);
                    temp.put(FIFTH_COLUMN, data.Value5);

                    list.add(temp);
                }

                for(int i = 0; i < list.size(); i++) {
                    HashMap temp =list.get(i);
                }

                adapter= new ListviewAdapterViewDataList(act,list);
                listView1.setAdapter(adapter);
            }

        }
        catch(Exception e){
            //	Toast.makeText(getApplicationContext(), "error" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }


    public ArrayList<BeanDetails> getData(){

        try{


            cursor = database.query(DatabaseHelper.DataDetails_info_TABLE_NAME,
                    fields, null, null, null, null, null);

            cursor.moveToFirst();
            do{
                bean.Value1 = cursor.getString(cursor.getColumnIndex("datetime"));
                bean.Value2 = cursor.getString(cursor.getColumnIndex("temperature"));
                bean.Value3 = cursor.getString(cursor.getColumnIndex("smoke"));
                bean.Value4 = cursor.getString(cursor.getColumnIndex("obstacles"));
                bean.Value4 = cursor.getString(cursor.getColumnIndex("torch"));

                ar_bean.add(new BeanDetails(bean.Value1, bean.Value2, bean.Value3, bean.Value4, bean.Value5));

            }while(cursor.moveToNext());
            return ar_bean;
        }
        catch(Exception e){
            Toast.makeText(getApplicationContext(), "Sorry No Data Exists", Toast.LENGTH_SHORT).show();
            return null;
        }
    }


    @Override
    public void onBackPressed() {
        // TODO Auto-generated method stub
        super.onBackPressed();

        finish();
        Intent mainscreen = new Intent(getApplicationContext(), MainScreenActivity.class);
        startActivity(mainscreen);

    }

}
